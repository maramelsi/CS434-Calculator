package OperationStrategy;

public abstract class UnaryOperation extends Operation {
    public UnaryOperation(){
        super.name = "unary";
    }
    public abstract double calculate(double firstOperand);
}
