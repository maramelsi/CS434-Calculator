package CommandPattern;

import FrameFactory.Calculator;
import OperationStrategy.Operation;

import java.util.ArrayList;

public class CommandHistory {
    private Calculator calculator;
    private Command command;
    private ArrayList<Command> history = new ArrayList<>();
    private static int current = 0;

    public void redo(int steps) {
        for (int i = 0; i < steps; i++) {
            if (current < history.size()) {
                Command command = history.get(current);
                current++;
                command.execute();
            }
        }
    }

    public void undo(int steps) {
        for (int i = 0; i < steps; i++) {
            if (current >= 0) {
                current--;
                Command command = history.get(current);
                command.unExecute();
            }
        }
    }

    public void compute(Operation operation, String operand) {
        Command command = new ConcreteCommand(
                calculator, operation, operand);
        //fix later
        command.execute();

        history.add(command);
        current++;
    }
}
