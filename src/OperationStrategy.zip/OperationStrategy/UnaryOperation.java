package OperationStrategy;

public abstract class UnaryOperation extends Operation {
    private String name;
    public abstract double calculate(double firstOperand);

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
