package OperationStrategy;

public abstract class BinaryOperation extends Operation {
    private String name;
    public abstract double calculate(double firstOperand, double secondOperand);

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
